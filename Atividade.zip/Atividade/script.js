const cartaoArtigo = document.querySelector('.cartao-artigo');
const botaoCompartilhar = document.querySelector('.botao-compartilhar');

if (botaoCompartilhar && cartaoArtigo) {
  const definirEstadoCompartilhar = (ativo) => {
    cartaoArtigo.classList.toggle('compartilhar-ativo', ativo);
    botaoCompartilhar.setAttribute('aria-expanded', String(ativo));
  };

  botaoCompartilhar.addEventListener('click', () => {
    const ativo = cartaoArtigo.classList.toggle('compartilhar-ativo');
    botaoCompartilhar.setAttribute('aria-expanded', String(ativo));
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
      definirEstadoCompartilhar(false);
      botaoCompartilhar.focus();
    }
  });
}